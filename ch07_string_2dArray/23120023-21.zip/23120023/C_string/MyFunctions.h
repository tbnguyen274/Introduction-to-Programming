﻿// -Chủ đề 2 về "C_string" làm trang 15 + 16: có khoảng 7 ý nhỏ

#include <iostream>
#include <iomanip>
#include <string.h>
using namespace std;

//1
void stringInput(char a[], int count);

void removeMultiSpace(char a[]);

// 2
int countStringWord(char a[]);

// 3
void printEachWord(char a[]);

// 4
void findLongestWord(char a[]);

// 5
void findFirstSubstring(char a[]);

// 6
void findLastSubstring(char a[]);

// 7
void findSubString(char a[]);