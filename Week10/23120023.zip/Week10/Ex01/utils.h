#include <iostream>
#include <cmath>
using namespace std;

struct Point2D {
	float x;
	float y;
};

void input(Point2D& p);
void print(Point2D p);
float findDistance(Point2D p1, Point2D p2);

